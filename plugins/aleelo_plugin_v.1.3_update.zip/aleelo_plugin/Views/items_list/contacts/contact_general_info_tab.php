<div class="tab-content">
    <?php echo form_open(get_uri("items_list/save_contact/"), array("id" => "contact-form", "class" => "general-form dashed-row white", "role" => "form")); ?>
    <div class="card">
        <div class=" card-header">
            <h4> <?php echo app_lang('general_info'); ?></h4>
        </div>
        <div class="card-body">
            <?php echo view("aleelo_plugin\Views/items_list/contacts/contact_general_info_fields"); ?>
        </div>
        <?php if ($can_edit_clients) { ?>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
            </div>
        <?php } ?>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $("#contact-form").appForm({
            isModal: false,
            onSuccess: function (result) {
                appAlert.success(result.message, {duration: 10000});
                setTimeout(function () {
                    window.location.href = "<?php echo get_uri("items_list/contact_profile/" . $model_info->id); ?>" + "/general";
                }, 500);
            }
        });
    });
</script>