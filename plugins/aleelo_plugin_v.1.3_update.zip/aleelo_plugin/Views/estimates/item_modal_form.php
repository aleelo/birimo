<?php echo form_open(get_uri("estimates/save_item"), array("id" => "estimate-item-form", "class" => "general-form", "role" => "form")); ?>
<div class="modal-body clearfix">
    <div class="container-fluid">
        <input type="hidden" name="id" value="<?php echo $model_info->id; ?>" />
        <input type="hidden" id="item_id" name="item_id" value="" />
        <input type="hidden" name="estimate_id" value="<?php echo $estimate_id; ?>" />
        <input type="hidden" name="add_new_item_to_library" value="" id="add_new_item_to_library" />
        <input type="hidden" name="new_account" value="" id="new_account" />

        <div class="form-group">
            <div class="row">
                <label for="estimate_item_title" class=" col-md-3"><?php echo app_lang('item'); ?></label>
                <div class="col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "estimate_item_title",
                        "name" => "estimate_item_title",
                        "value" => $model_info->title,
                        "class" => "form-control validate-hidden",
                        "placeholder" => app_lang('select_or_create_new_item'),
                        "data-rule-required" => true,
                        "data-msg-required" => app_lang("field_required"),
                    ));
                    ?>
                    <a id="estimate_item_title_dropdwon_icon" tabindex="-1" href="javascript:void(0);" style="color: #B3B3B3;float: right; padding: 5px 7px; margin-top: -35px; font-size: 18px;"><span>×</span></a>
                </div>
            </div>
        </div>
    

        <div class="form-group">
            <div class="row">
                <label for="estimate_item_description" class="col-md-3"><?php echo app_lang('description'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_textarea(array(
                        "id" => "estimate_item_description",
                        "name" => "estimate_item_description",
                        "value" => $model_info->description ? process_images_from_content($model_info->description, false) : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('description'),
                        "data-rich-text-editor" => true
                    ));
                    ?>
                </div>
            </div>
        </div>
                 <div class="form-group">
            <div class="row">
                <label for="estimate_item_days" class="col-md-3"><?php echo app_lang('days'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "days",
                        "name" => "days",
                        "value" => $model_info->days ? $model_info->days : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('days')
                    ));
                    ?>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <label for="estimate_item_quantity" class=" col-md-3"><?php echo app_lang('quantity'); ?></label>
                <div class="col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "estimate_item_quantity",
                        "name" => "estimate_item_quantity",
                        "value" => $model_info->quantity ? to_decimal_format($model_info->quantity) : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('quantity'),
                        "data-rule-required" => true,
                        "data-msg-required" => app_lang("field_required"),
                    ));
                    ?>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <label for="estimate_unit_type" class=" col-md-3"><?php echo app_lang('unit_type'); ?></label>
                <div class="col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "estimate_unit_type",
                        "name" => "estimate_unit_type",
                        "value" => $model_info->unit_type,
                        "class" => "form-control",
                        "placeholder" => app_lang('unit_type') . ' (Ex: hours, pc, etc.)'
                    ));
                    ?>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <label for="estimate_item_rate" class=" col-md-3"><?php echo app_lang('rate'); ?></label>
                <div class="col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "estimate_item_rate",
                        "name" => "estimate_item_rate",
                        "value" => $model_info->rate ? to_decimal_format($model_info->rate) : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('rate'),
                        "data-rule-required" => true,
                        "data-msg-required" => app_lang("field_required"),
                    ));
                    ?>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <label for="supplier" class=" col-md-3 col-xs-5 col-sm-4"><?php echo ('from supplier'); ?></label>
                <div class=" col-md-9 col-xs-7 col-sm-8">
                    <?php
                    echo form_checkbox("supplier", "1", $model_info->supplier ? true : false, "id='supplier' class='form-check-input'");
                    ?>                       
                </div>
            </div>
        </div>

        <div id="cheked" class="hide" >
        <div class="form-group">
            <div class="row">
                <label for="company_id" class="col-md-3"><?php echo 'supplier'; ?></label>
                <div class="col-md-9">
                    <?php 
                    echo form_dropdown(array( 
                        'id'=> "supplier_id",
                        'name'=> "supplier_id",
                        'class' => "form-control select2",
                        "value" => $model_info->supplier_id,
                        'autocomplete'=> "off",
                        
                    ), $supplier_id, [$model_info->supplier_id]); 
                    ?>
                </div>
            </div>
        </div>

<div class="form-group">
            <div class="row">
                <label for="supplier_price" class=" col-md-3"><?php echo ('supplier price'); ?></label>
                <div class="col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "supplier_price",
                        "name" => "supplier_price",
                        "value" => $model_info->supplier_quantity ? to_decimal_format($model_info->supplier_quantity) : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('rate'),
                        
                    ));
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
    <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
</div>
<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $("#estimate-item-form").appForm({
            onSuccess: function (result) {
                $("#estimate-item-table").appTable({newData: result.data, dataId: result.id});
                $("#estimate-total-section").html(result.estimate_total_view);
                if (typeof updateInvoiceStatusBar == 'function') {
                    updateInvoiceStatusBar(result.estimate_id);
                }
            }
        });

        //show item suggestion dropdown when adding new item
        var isUpdate = "<?php echo $model_info->id; ?>";
        if (!isUpdate) {
            applySelect2OnItemTitle();
            

        }

        //re-initialize item suggestion dropdown on request
        $("#estimate_item_title_dropdwon_icon").click(function () {
            applySelect2OnItemTitle();
        })

    });
 

    function applySelect2OnItemTitle() {
        $("#estimate_item_title").select2({
            showSearchBox: true,
            ajax: {
                url: "<?php echo get_uri("estimates/get_estimate_item_suggestion"); ?>",
                type: 'POST',
                dataType: 'json',
                quietMillis: 250,
                data: function (term, page) {
                    return {
                        q: term // search term
                    };
                },
                results: function (data, page) {
                    return {results: data};
                }
            }
        }).change(function (e) {
            if (e.val === "+") {
                //show simple textbox to input the new item
                $("#estimate_item_title").select2("destroy").val("").focus();
                $("#add_new_item_to_library").val(1); //set the flag to add new item in library
            } else if (e.val) {
                //get existing item info
                $("#add_new_item_to_library").val(""); //reset the flag to add new item in library
                $.ajax({
                    url: "<?php echo get_uri("estimates/get_estimate_item_info_suggestion"); ?>",
                    data: {item_id: e.val},
                    cache: false,
                    type: 'POST',
                    dataType: "json",
                    success: function (response) {

                        //auto fill the description, unit type and rate fields.
                        if (response && response.success) {
                            $("#item_id").val(response.item_info.id);
                            $("#estimate_item_title").val(response.item_info.title);
                            
                            $("#estimate_item_description").val(response.item_info.description);

                            $("#estimate_unit_type").val(response.item_info.unit_type);

                            $("#estimate_item_rate").val(response.item_info.rate);
                            $("#estimate_item_quantity").val(response.item_info.quantity ? toDecimalFormat(response.item_info.quantity) : "");
                            $("#estimate_item_account_id").val(response.item_info.account_id ? response.item_info.account_id : "");
                        }
                    }
                });
            }

        });
    }
    $("#supplier_id").select2();


toggleSupplierFields();

$("#supplier").change(function () {
    toggleSupplierFields(); 
});

function toggleSupplierFields() {
    if ($("#supplier").is(":checked")) {
        $("#cheked").removeClass("hide");
    } else {
        $("#cheked").addClass("hide");
    }
}
</script>