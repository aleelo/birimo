<?php echo form_open(get_uri("project/save"), array("id" => "project-form", "class" => "general-form", "role" => "form")); ?>
<div class="modal-body clearfix">
    <div class="container-fluid">
        <input type="hidden" name="id" value="<?php echo $model_info->id; ?>" />
        <input type="hidden" name="estimate_id" value="<?php echo $model_info->estimate_id; ?>" />
        <input type="hidden" name="order_id" value="<?php echo $model_info->order_id; ?>" />

        <!----------------------------------------- Company ------------------------------------>
        <?php if ($has_all_permission){ ?>

        <div class="form-group">
            <div class="row">
                <label for="department_id" class=" col-md-3"><?php echo 'Company'; ?></label>
                <div class=" col-md-9">
                <?php 
                echo form_dropdown(array( 
                        'id'=> "department_id",
                        'name'=> "department_id",
                        'class' => "form-control select2",
                        'placeholder' => 'Company',
                        'autocomplete'=> "off",
                        'data-rule-required' => true,
                        'data-msg-required' =>   app_lang('field_required')
                    ),$departments,[$model_info->company_id]); ?>
                </div>
            </div>
        </div> 
        <?php } else{ ?>
            <input type="hidden" id="department_id" name="department_id" value="<?php echo $login_user->department; ?>">
            <?php } ?>


        <!----------------------------------------- Title ------------------------------------>

        <div class="form-group">
            <div class="row">
                <label for="title" class=" col-md-3"><?php echo app_lang('title'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "title",
                        "name" => "title",
                        "value" => $model_info->title,
                        "class" => "form-control",
                        "placeholder" => app_lang('title'),
                        "autofocus" => true,
                        "data-rule-required" => true,
                        "data-msg-required" => app_lang("field_required"),
                    ));
                    ?>
                </div> 
            </div>
        </div>

        <!----------------------------------------- Project Type ------------------------------------>

        <?php if ($client_id || $login_user->user_type == "client") { ?>
            <input type="hidden" name="project_type" value="client_project" />
        <?php } else { ?>
            <div class="form-group">
                <div class="row">
                    <label for="project_type" class=" col-md-3"><?php echo app_lang('project_type'); ?></label>
                    <div class=" col-md-9">
                        <?php
                        echo form_dropdown("project_type", array(
                            "client_project" => app_lang("client_project"),
                            "internal_project" => app_lang("internal_project"),
                                ), array($model_info->project_type ? $model_info->project_type : "client_project"), "class='select2 validate-hidden' data-rule-required='true', data-msg-required='" . app_lang('field_required') . "' id='project-type-dropdown'");
                        ?>
                    </div>
                </div>
            </div>
        <?php } ?>

        <?php if ($client_id) { ?>
            <input type="hidden" name="client_id" value="<?php echo $client_id; ?>" />
        <?php } else if ($login_user->user_type == "client" || $hide_clients_dropdown) { ?>
            <input type="hidden" name="client_id" value="<?php echo $model_info->client_id; ?>" />
            
        <?php } else { ?>

            <div class="form-group <?php echo $model_info->project_type === "internal_project" ? 'hide' : ''; ?>" id="clients-dropdown">
                <div class="row">
                    <label for="client_id" class=" col-md-3"><?php echo app_lang('client'); ?></label>
                    <div class=" col-md-9">
                        <?php
                        echo form_dropdown("client_id", $clients_dropdown, array($model_info->client_id), "class='select2 validate-hidden' data-rule-required='true', data-msg-required='" . app_lang('field_required') . "'");
                        ?>
                    </div>
                </div>
            </div>
            
        <?php } ?>

         <!----------------------------------------- Project Name ------------------------------------>

         <!-- <div class="form-group" id="project_name_section">
            <div class="row">
                <label for="project_name" class=" col-md-3"><?php //echo app_lang('project_name'); ?></label>
                <div class=" col-md-9">
                    <?php
                    // echo form_input(array(
                    //     "id" => "project_name",
                    //     "name" => "project_name",
                    //     "value" => $model_info->project_name,
                    //     "class" => "form-control",
                    //     "placeholder" => app_lang('project_name'),
                    //     "autofocus" => true,
                    // ));
                    ?>
                </div> 
            </div>
        </div> -->

        <!----------------------------------------- Description ------------------------------------>

        <div class="form-group">
            <div class="row">
                <label for="description" class=" col-md-3"><?php echo app_lang('description'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_textarea(array(
                        "id" => "description",
                        "name" => "description",
                        "value" => process_images_from_content($model_info->description, false),
                        "class" => "form-control",
                        "placeholder" => app_lang('description'),
                        "style" => "height:150px;",
                        "data-rich-text-editor" => true
                    ));
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Supervisor ------------------------------------>

        <div class="form-group" id="supervisor_section">
            <div class="row">
                
                <label for="supervisor_id" class="col-md-3"><?php echo 'Supervisor'; ?></label>
                <div class=" col-md-9">
                    <?php
                    // $Training_Type = [''=>' -- ','4 * 3 meter'=>'4 * 3 meter','9 * 2 meter'=>'9 * 2 meter','Others'=>'Others'];
                    echo form_dropdown(array(
                        "id" => "supervisor_id",
                        "name" => "supervisor_id",
                        "class" => "form-control select2",
                        "placeholder" => 'Supervisor',
                        "autocomplete" => "off"
                    ),$employees,[$model_info->supervisor_id]);
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Location ------------------------------------>

        <div class="form-group" id="location_section">
            <div class="row">
                <label for="location" class="col-md-3"><?php echo app_lang('location'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "location",
                        "name" => "location",
                        "value" => $model_info->location,
                        "class" => "form-control",
                        "placeholder" => app_lang('location'),
                        "autofocus" => true,
                        // "data-rule-required" => true,
                        // "data-msg-required" => app_lang("field_required"),
                    ));
                    ?>
                </div> 
            </div>
        </div>

        <!----------------------------------------- Screen Size ------------------------------------>

        <div class="form-group" id="screen_size_section">
            <div class="row">
                
                <label for="screen_size_id" class="col-md-3"><?php echo 'Screen Size'; ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_dropdown(array(
                        "id" => "screen_size_id",
                        "name" => "screen_size_id",
                        "class" => "form-control select2",
                        "placeholder" => 'Screen Size',
                        "autocomplete" => "off"
                    ),$screen_sizes,[$model_info->screen_size_id]);
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Start Date ------------------------------------>

        <div class="form-group">
            <div class="row">
                <label for="start_date" class=" col-md-3"><?php echo app_lang('start_date'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "start_date",
                        "name" => "start_date",
                        "value" => is_date_exists($model_info->start_date) ? $model_info->start_date : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('start_date'),
                        "autocomplete" => "off"
                    ));
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Deadline ------------------------------------>

        <div class="form-group">
            <div class="row">
                <label for="deadline" class=" col-md-3"><?php echo app_lang('deadline'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "deadline",
                        "name" => "deadline",
                        "value" => is_date_exists($model_info->deadline) ? $model_info->deadline : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('deadline'),
                        "autocomplete" => "off"
                    ));
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Project Date ------------------------------------>

        <div class="form-group" id="project_date_section">
            <div class="row">
                <label for="project_date" class=" col-md-3"><?php echo app_lang('project_date'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "project_date",
                        "name" => "project_date",
                        "value" => is_date_exists($model_info->project_date) ? $model_info->project_date : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('project_date'),
                        "autocomplete" => "off"
                    ));
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Price ------------------------------------>

        <div class="form-group">
            <div class="row">
                <label for="price" class=" col-md-3"><?php echo app_lang('price'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "price",
                        "name" => "price",
                        "value" => $model_info->price ? to_decimal_format($model_info->price) : "",
                        "class" => "form-control",
                        "placeholder" => app_lang('price')
                    ));
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Labels ------------------------------------>

        <div class="form-group">
            <div class="row">
                <label for="project_labels" class=" col-md-3"><?php echo app_lang('labels'); ?></label>
                <div class=" col-md-9">
                    <?php
                    echo form_input(array(
                        "id" => "project_labels",
                        "name" => "labels",
                        "value" => $model_info->labels,
                        "class" => "form-control",
                        "placeholder" => app_lang('labels')
                    ));
                    ?>
                </div>
            </div>
        </div>

        <!----------------------------------------- Status ------------------------------------>

        <?php if ($model_info->id) { ?>
            <div class="form-group">
                <div class="row">
                    <label for="status_id" class=" col-md-3"><?php echo app_lang('status'); ?></label>
                    <div class="col-md-9">
                        <?php
                        foreach ($statuses as $status) {
                            $project_status[$status->id] = $status->key_name ? app_lang($status->key_name) : $status->title;
                        }

                        echo form_dropdown("status_id", $project_status, array($model_info->status_id), "class='select2'");
                        ?>
                    </div>
                </div>
            </div>
        <?php } ?>

        <?php echo view("custom_fields/form/prepare_context_fields", array("custom_fields" => $custom_fields, "label_column" => "col-md-3", "field_column" => " col-md-9")); ?> 

    </div>
</div>

<div class="modal-footer">
    <div id="link-of-add-project-member-modal" class="hide">
        <?php echo modal_anchor(get_uri("project/project_member_modal_form"), "", array()); ?>
    </div>

    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
    <?php if (!$model_info->id && $login_user->user_type != "client" && $can_edit_projects) { ?>
        <button type="button" id="save-and-continue-button" class="btn btn-info text-white"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save_and_continue'); ?></button>
    <?php } ?>
    <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
</div>
<?php echo form_close(); ?>

<script type="text/javascript">
    $(document).ready(function () {
        window.projectForm = $("#project-form").appForm({
            closeModalOnSuccess: false,
            onSuccess: function (result) {
                if (typeof RELOAD_PROJECT_VIEW_AFTER_UPDATE !== "undefined" && RELOAD_PROJECT_VIEW_AFTER_UPDATE) {
                    location.reload();

                    window.projectForm.closeModal();
                } else if (typeof RELOAD_VIEW_AFTER_UPDATE !== "undefined" && RELOAD_VIEW_AFTER_UPDATE) {
                    RELOAD_VIEW_AFTER_UPDATE = false;
                    window.location = "<?php echo site_url('project/view'); ?>/" + result.id;

                    window.projectForm.closeModal();
                } else if (window.showAddNewModal) {
                    var $addProjectMemberLink = $("#link-of-add-project-member-modal").find("a");

                    $addProjectMemberLink.attr("data-action-url", "<?php echo get_uri("project/project_member_modal_form"); ?>");
                    $addProjectMemberLink.attr("data-title", "<?php echo app_lang("add_new_project_member"); ?>");
                    $addProjectMemberLink.attr("data-post-project_id", result.id);
                    $addProjectMemberLink.attr("data-post-view_type", "from_project_modal");

                    $addProjectMemberLink.trigger("click");

                    $("#project-table").appTable({newData: result.data, dataId: result.id});
                } else {
                    $("#project-table").appTable({newData: result.data, dataId: result.id});

                    window.projectForm.closeModal();
                }
            }
        });

        setTimeout(function () {
            $("#title").focus();
        }, 200);
        $("#project-form .select2").select2();

        setDatePicker("#start_date, #deadline, #project_date");

        $("#project_labels").select2({multiple: true, data: <?php echo json_encode($label_suggestions); ?>});

        //save and open add new project member modal
        window.showAddNewModal = false;

        $("#save-and-continue-button").click(function () {
            window.showAddNewModal = true;
            $(this).trigger("submit");
        });


        function validateClientDropdown() {
            if ($("#project-type-dropdown").val() === "internal_project") {
                $("#clients-dropdown").addClass("hide");
                $("#clients-dropdown").find(".select2").removeClass("validate-hidden");
                $("#clients-dropdown").find(".select2").removeAttr("data-rule-required");
            } else {
                $("#clients-dropdown").removeClass("hide");
                $("#clients-dropdown").find(".select2").addClass("validate-hidden");
                $("#clients-dropdown").find(".select2").attr("data-rule-required", true);
            }
        }


        $("#project-type-dropdown").select2().on("change", function () {
            validateClientDropdown();
        });

        setTimeout(function () {
            validateClientDropdown();
        });

// ------------------------------- Aleelo Pixel ----------------------------------------------------------------------------------------------- //


        function resetOtherDropdowns(excludeSection) {
        var sections = ['#supervisor_section','#location_section','#screen_size_section','#project_date_section','#project_name_section'];
        
        // Remove the excluded section from the list
        sections = sections.filter(function (item) {
            return item !== excludeSection;
        });

        // Loop through each section and reset the values
        sections.forEach(function (section) {
            $(section + ' select').val(null).trigger('change'); // Clear selection
        });
    }

        // Initially hide all sections
        function hideAllSections() {
            $('#supervisor_section').hide();
            $('#location_section').hide();
            $('#screen_size_section').hide();
            $('#project_date_section').hide();
            $('#project_name_section').hide();
        }

        // Call this function whenever the "Meeting With" dropdown changes
        $('#department_id').on('change', function () {
            var department_id = $(this).val();

            // Hide all sections first
            hideAllSections();

            // Show the appropriate section(s) based on the selected meeting_with value and reset others
            switch (department_id) {
                case '1':
                    $('#supervisor_section').show();
                    $('#location_section').show();
                    $('#screen_size_section').show();
                    $('#project_date_section').show();
                    $('#project_name_section').show();
                    resetOtherDropdowns('#supervisor_section','#location_section','#screen_size_section','#project_date_section','project_name_section');
                    break;
                default:
                    hideAllSections(); // If no valid selection is made, hide all sections and reset all dropdowns
                    resetOtherDropdowns(null);
            }
        });

        // Trigger change on page load to set the correct visibility based on any pre-selected value
        $('#department_id').trigger('change');

    });
</script>    